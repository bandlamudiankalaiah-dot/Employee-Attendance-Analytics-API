from datetime import datetime, date, timedelta, timezone
from decimal import Decimal
import pytest
from app.main import (
    IST_TZ,
    round_half_up,
    calculate_late_minutes,
    calculate_work_and_overtime,
    determine_shift_date_and_times,
    epoch_ms_to_utc_dt,
    dt_to_epoch_ms
)

# -------------------------------------------------------------
# Unit Tests: Business Rules & Rounding
# -------------------------------------------------------------

def test_decimal_round_half_up():
    """R4: Contractual Decimal half-up rounding vs Python banker's rounding."""
    # 4.455 with half-up must be 4.46 (Python default round(4.455, 2) is 4.45)
    assert round_half_up(4.455, 2) == 4.46
    assert round_half_up(4.495, 2) == 4.50
    assert round_half_up(4.494, 2) == 4.49

def test_late_minutes_grace_period_boundaries():
    """R2: Grace period: 10 mins. Strictly > 10m is late, calculated from shift start."""
    sched_start_ist = datetime(2024, 5, 20, 9, 30, 0, tzinfo=IST_TZ)
    sched_start_utc = sched_start_ist.astimezone(timezone.utc)
    
    # Exactly on time: 09:30:00 -> 0
    p1 = sched_start_utc
    assert calculate_late_minutes(p1, sched_start_utc) == 0
    
    # Exactly at grace limit: 09:40:00 (600s) -> 0
    p2 = sched_start_utc + timedelta(seconds=600)
    assert calculate_late_minutes(p2, sched_start_utc) == 0
    
    # 1 second past grace: 09:40:01 (601s) -> 10 whole minutes elapsed
    p3 = sched_start_utc + timedelta(seconds=601)
    assert calculate_late_minutes(p3, sched_start_utc) == 10
    
    # 10:15:59 (45m 59s = 2759s) -> 45 minutes
    p4 = sched_start_utc + timedelta(minutes=45, seconds=59)
    assert calculate_late_minutes(p4, sched_start_utc) == 45

def test_overtime_threshold_and_half_day():
    """R3, R4, R5: Overtime >= 30m, work_hours rounding, half_day < 4.50."""
    p_in = datetime(2024, 5, 20, 4, 0, 0, tzinfo=timezone.utc)
    sched_end = datetime(2024, 5, 20, 13, 0, 0, tzinfo=timezone.utc)
    
    # 29 minutes after shift end: OT < 30m -> 0
    p_out_29m = sched_end + timedelta(minutes=29, seconds=59)
    wh, ot, hd = calculate_work_and_overtime(p_in, p_out_29m, sched_end)
    assert ot == 0
    assert hd is False
    
    # Exactly 30 minutes after shift end: OT = 30
    p_out_30m = sched_end + timedelta(minutes=30)
    wh, ot, hd = calculate_work_and_overtime(p_in, p_out_30m, sched_end)
    assert ot == 30
    assert hd is False
    
    # Half-day test: punch out after 4 hours 29 minutes (work_hours < 4.50)
    p_out_short = p_in + timedelta(hours=4, minutes=29)
    wh, ot, hd = calculate_work_and_overtime(p_in, p_out_short, sched_end)
    assert wh < 4.50
    assert hd is True

def test_overnight_shift_date_attribution():
    """R1: Overnight shifts: punch-in before shift_end belongs to previous day."""
    # Shift: 22:00 to 06:00
    # Punch in at 01:30 AM IST on May 21
    p_in_ist = datetime(2024, 5, 21, 1, 30, 0, tzinfo=IST_TZ)
    p_in_utc = p_in_ist.astimezone(timezone.utc)
    
    shift_date, sched_start_utc, sched_end_utc = determine_shift_date_and_times(
        p_in_utc, "22:00", "06:00"
    )
    # Must be attributed to May 20
    assert shift_date == "2024-05-20"
    # Scheduled start is May 20 22:00 IST
    assert sched_start_utc == datetime(2024, 5, 20, 22, 0, 0, tzinfo=IST_TZ).astimezone(timezone.utc)
    # Scheduled end is May 21 06:00 IST
    assert sched_end_utc == datetime(2024, 5, 21, 6, 0, 0, tzinfo=IST_TZ).astimezone(timezone.utc)

# -------------------------------------------------------------
# Integration Tests: Employee Endpoints
# -------------------------------------------------------------

def test_create_employee_success(client):
    payload = {
        "emp_code": "TEST01",
        "name": "Test User",
        "email": "test@example.com",
        "department": "Engineering",
        "shift_start": "09:30",
        "shift_end": "18:30",
        "joined_on": "2024-01-15"
    }
    res = client.post("/employees", json=payload)
    assert res.status_code == 201
    data = res.json()
    assert data["emp_code"] == "TEST01"
    assert "_id" not in data
    assert "created_at" in data

def test_create_duplicate_employee_conflict(client):
    payload = {
        "emp_code": "TEST_DUP",
        "name": "Test User",
        "email": "dup@example.com",
        "department": "Engineering",
        "shift_start": "09:30",
        "shift_end": "18:30",
        "joined_on": "2024-01-15"
    }
    res1 = client.post("/employees", json=payload)
    assert res1.status_code == 201
    
    # Second create with same emp_code must return 409
    res2 = client.post("/employees", json=payload)
    assert res2.status_code == 409

def test_create_employee_identical_shifts_rejected(client):
    payload = {
        "emp_code": "TEST_BAD",
        "name": "Test User",
        "email": "bad@example.com",
        "department": "Engineering",
        "shift_start": "09:00",
        "shift_end": "09:00",  # Identical
        "joined_on": "2024-01-15"
    }
    res = client.post("/employees", json=payload)
    assert res.status_code == 422

def test_create_employee_impossible_date_rejected(client):
    payload = {
        "emp_code": "TEST_LEAP",
        "name": "Test User",
        "email": "leap@example.com",
        "department": "Engineering",
        "shift_start": "09:00",
        "shift_end": "18:00",
        "joined_on": "2024-02-31"  # Impossible date
    }
    res = client.post("/employees", json=payload)
    assert res.status_code == 422

def test_list_employees_pagination_and_filter(client):
    for i, dept in [(1, "HR"), (2, "HR"), (3, "Finance")]:
        client.post("/employees", json={
            "emp_code": f"EMP_L_{i}",
            "name": f"User {i}",
            "email": f"user{i}@company.com",
            "department": dept,
            "shift_start": "09:00",
            "shift_end": "18:00",
            "joined_on": "2024-01-01"
        })
        
    res_hr = client.get("/employees?department=HR")
    assert res_hr.status_code == 200
    hr_data = res_hr.json()
    assert hr_data["total"] == 2
    assert len(hr_data["items"]) == 2
    assert all(it["department"] == "HR" for it in hr_data["items"])
    
    res_page = client.get("/employees?page=1&page_size=1")
    assert res_page.status_code == 200
    page_data = res_page.json()
    assert len(page_data["items"]) == 1
    assert page_data["page_size"] == 1
    assert page_data["total"] >= 3

# -------------------------------------------------------------
# Integration Tests: Attendance Punch-in & Punch-out
# -------------------------------------------------------------

def test_punch_in_and_punch_out_flow(client):
    client.post("/employees", json={
        "emp_code": "PUNCH_EMP",
        "name": "Punch Tester",
        "email": "punch@company.com",
        "department": "Engineering",
        "shift_start": "09:30",
        "shift_end": "18:30",
        "joined_on": "2024-01-01"
    })
    
    p_in_ms = 1716177600000
    res_in = client.post("/attendance/punch-in", json={
        "emp_code": "PUNCH_EMP",
        "punched_at": p_in_ms,
        "status": "PRESENT"
    })
    assert res_in.status_code == 201
    in_data = res_in.json()
    assert in_data["date"] == "2024-05-20"
    assert in_data["late_minutes"] == 0
    assert in_data["punch_out"] is None
    assert in_data["half_day"] is False
    assert in_data["history"] == []
    
    # Duplicate punch in on same day -> 409 Conflict
    res_dup = client.post("/attendance/punch-in", json={
        "emp_code": "PUNCH_EMP",
        "punched_at": p_in_ms + 60000
    })
    assert res_dup.status_code == 409
    
    p_out_ms = 1716212700000
    res_out = client.post("/attendance/punch-out", json={
        "emp_code": "PUNCH_EMP",
        "punched_at": p_out_ms
    })
    assert res_out.status_code == 200
    out_data = res_out.json()
    assert out_data["work_hours"] == 9.75
    assert out_data["overtime_minutes"] == 45
    assert out_data["half_day"] is False
    
    # Double punch out -> 404 or 409
    res_out_dup = client.post("/attendance/punch-out", json={
        "emp_code": "PUNCH_EMP",
        "punched_at": p_out_ms + 10000
    })
    assert res_out_dup.status_code in [404, 409]

def test_punch_in_boolean_timestamp_rejected(client):
    client.post("/employees", json={
        "emp_code": "BOOL_EMP",
        "name": "Bool Tester",
        "email": "bool@company.com",
        "department": "Engineering",
        "shift_start": "09:30",
        "shift_end": "18:30",
        "joined_on": "2024-01-01"
    })
    res = client.post("/attendance/punch-in", json={
        "emp_code": "BOOL_EMP",
        "punched_at": True  # Boolean must be rejected
    })
    assert res.status_code == 422

def test_punch_in_float_timestamp_rejected(client):
    res = client.post("/attendance/punch-in", json={
        "emp_code": "BOOL_EMP",
        "punched_at": 1716177600000.55  # Float must be rejected
    })
    assert res.status_code == 422

def test_attendance_listing_date_validations(client):
    # Invalid calendar date
    res1 = client.get("/attendance?date_from=2024-02-31")
    assert res1.status_code == 422
    
    # Reversed date range
    res2 = client.get("/attendance?date_from=2024-05-20&date_to=2024-05-10")
    assert res2.status_code == 422

# -------------------------------------------------------------
# Integration Tests: Attendance Regularization & Audit
# -------------------------------------------------------------

def test_attendance_regularization_audit_history(client):
    client.post("/employees", json={
        "emp_code": "REG_EMP",
        "name": "Reg User",
        "email": "reg@company.com",
        "department": "Engineering",
        "shift_start": "09:30",
        "shift_end": "18:30",
        "joined_on": "2024-01-01"
    })
    
    client.post("/attendance/punch-in", json={
        "emp_code": "REG_EMP",
        "punched_at": 1716177600000,
        "status": "PRESENT"
    })
    
    patch_res = client.patch("/attendance/REG_EMP/2024-05-20", json={
        "regularized_by": "manager_alice",
        "reason": "Approved remote work",
        "status": "WFH"
    })
    assert patch_res.status_code == 200
    updated = patch_res.json()
    assert updated["status"] == "WFH"
    assert len(updated["history"]) == 1
    h_entry = updated["history"][0]
    assert h_entry["by"] == "manager_alice"
    assert h_entry["reason"] == "Approved remote work"
    assert h_entry["changes"]["status"]["old"] == "PRESENT"
    assert h_entry["changes"]["status"]["new"] == "WFH"

def test_regularization_noop_does_not_append_history(client):
    # Same status regularized
    patch_res = client.patch("/attendance/REG_EMP/2024-05-20", json={
        "regularized_by": "manager_alice",
        "reason": "Redundant click",
        "status": "WFH"
    })
    assert patch_res.status_code == 200
    updated = patch_res.json()
    # History length should remain 1
    assert len(updated["history"]) == 1

def test_regularization_chronological_conflict_rejected(client):
    patch_res = client.patch("/attendance/REG_EMP/2024-05-20", json={
        "regularized_by": "manager_alice",
        "reason": "Bad punch times",
        "punch_in": 1716212700000,
        "punch_out": 1716177600000  # punch_out < punch_in
    })
    assert patch_res.status_code == 422

# -------------------------------------------------------------
# Integration Tests: Analytics Endpoints
# -------------------------------------------------------------

def test_employee_monthly_analytics_prorated_and_weekend(client):
    client.post("/employees", json={
        "emp_code": "ANALYTICS_EMP",
        "name": "Monthly Analytics User",
        "email": "monthly@company.com",
        "department": "Engineering",
        "shift_start": "09:30",
        "shift_end": "18:30",
        "joined_on": "2024-05-15"
    })
    
    res = client.get("/analytics/employees/ANALYTICS_EMP/monthly?month=2024-05")
    assert res.status_code == 200
    data = res.json()
    assert data["total_working_days"] > 0
    assert data["present_days"] == 0
    assert data["attendance_rate"] == 0.0

def test_admin_explain_endpoints(client):
    # Valid endpoints
    res1 = client.get("/admin/explain/attendance_list")
    assert res1.status_code == 200
    
    res2 = client.get("/admin/explain/employee_monthly")
    assert res2.status_code == 200
    
    # Invalid endpoint name -> 422
    res_inv = client.get("/admin/explain/unknown_nonexistent")
    assert res_inv.status_code == 422

def test_health_endpoint(client):
    res = client.get("/health")
    assert res.status_code == 200
    assert res.json()["status"] == "ok"
    assert res.json()["mongo_connected"] is True
