import os
import pytest
from mongomock import MongoClient as MockMongoClient
from fastapi.testclient import TestClient

# Configure environment before loading app
os.environ["MONGO_URI"] = "mongodb://localhost:27017"
os.environ["MONGO_DB"] = "test_attendance_db"

import app.main as app_module
from app.main import app

@pytest.fixture(autouse=True)
def setup_mock_db(monkeypatch):
    """
    Sets up an in-memory MockMongoClient for unit and integration testing.
    Initializes mock collections and indexes.
    """
    mock_client = MockMongoClient()
    mock_db = mock_client["test_attendance_db"]
    
    # Patch client and db in app.main
    monkeypatch.setattr(app_module, "client", mock_client)
    monkeypatch.setattr(app_module, "db", mock_db)
    
    # Initialize indexes
    app_module.init_db_indexes(mock_db)
    
    yield mock_db
    
    mock_client.close()

@pytest.fixture
def client(setup_mock_db):
    with TestClient(app) as test_client:
        yield test_client
