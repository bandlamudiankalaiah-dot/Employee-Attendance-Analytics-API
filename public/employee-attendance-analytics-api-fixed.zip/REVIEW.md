# Code Review & Defect Analysis (REVIEW.md)

This document catalogs the defects, race conditions, mathematical flaws, and architectural limitations identified in common starter implementations of the **Employee Attendance & Analytics API**, along with reproduction steps and implemented production fixes.

---

### Defect 1: Health Check False Positives
- **Location:** `GET /health`
- **What Was Wrong:** Starter implementations return `{"status": "ok"}` without pinging MongoDB, or fail to catch connection timeouts during startup, leading orchestrators (e.g. Kubernetes/Docker) to route traffic to an unusable container.
- **How to Reproduce:** Start the API without MongoDB running (`MONGO_URI="mongodb://localhost:27017"` when mongod is down). The endpoint previously returned HTTP 200.
- **How It Was Fixed:** Implemented an explicit `client.admin.command('ping')` call with a short serverSelectionTimeoutMS (2000ms). Returns HTTP 503 Service Unavailable if MongoDB is unreachable, ensuring accurate liveness and readiness reporting.

---

### Defect 2: Timezone-Naive Datetimes Causing IST Date Shift
- **Location:** Time conversion in punch-in/out logic
- **What Was Wrong:** Datetimes were parsed or converted using `datetime.utcnow()` or local host timezone without explicit `zoneinfo.ZoneInfo("Asia/Kolkata")`. Punch-ins at 02:00 AM IST (20:30 UTC previous day) or 23:30 IST were assigned to the wrong calendar date.
- **How to Reproduce:** Punch in at timestamp representing `2024-05-20 01:00:00 IST`. In UTC, this is `2024-05-19 19:30:00 UTC`. Naive string parsing assigned it to `2024-05-19`.
- **How It Was Fixed:** Standardized all business calendar calculations using explicit `zoneinfo.ZoneInfo("Asia/Kolkata")` (UTC+05:30) and timezone-aware objects.

---

### Defect 3: Millisecond vs. Second Timestamp Corruption
- **Location:** Request timestamp validation in `/attendance/punch-in` and `/attendance/punch-out`
- **What Was Wrong:** Timestamps were accepted as floats or seconds, or converted using `datetime.fromtimestamp(ts)` instead of `datetime.fromtimestamp(ts / 1000.0, tz=timezone.utc)`. Floating-point milliseconds introduced precision drift.
- **How to Reproduce:** Submit `"punched_at": 1716177600` (seconds instead of epoch ms). Naive code treated this as year 1970 or crashed.
- **How It Was Fixed:** Pydantic v2 strict integer validation enforces `StrictInt` epoch milliseconds (within range `1000000000000 <= ts <= 9999999999999`). Instant is integer-truncated to whole seconds: `(ms // 1000) * 1000`.

---

### Defect 4: Overnight Shift Misattribution to Current Calendar Date
- **Location:** Shift date determination for shifts where `shift_end <= shift_start` (e.g. 22:00 to 06:00)
- **What Was Wrong:** An employee clocking in at 01:15 AM IST for a 22:00–06:00 night shift was assigned to today's date rather than the shift date that started the previous evening.
- **How to Reproduce:** For a shift `22:00` to `06:00`, punch in at `02:00 AM` on May 21. Naive logic recorded `date = "2024-05-21"` instead of `"2024-05-20"`.
- **How It Was Fixed:** Implemented rule R1: If `shift_end <= shift_start` (overnight) and `punch_in_time < shift_end`, the attendance record is attributed to `calendar_date - 1 day`.

---

### Defect 5: Late Minutes Grace Period Boundary and Subtraction Error
- **Location:** `late_minutes` calculation
- **What Was Wrong:** Starter code either:
  1. Counted late minutes as `elapsed - 10` instead of elapsed minutes from scheduled shift start.
  2. Considered `shift_start + 10m` as late (using `>= 10` instead of `> 10`).
- **How to Reproduce:**
  - Shift start `09:30`.
  - Punch-in at `09:40:00` -> should be `0` late minutes. Starter gave 10 or 0.
  - Punch-in at `09:40:01` -> strictly > 10m grace -> should be `10` whole minutes elapsed from `09:30`. Starter gave `1` minute (`(10 min 1 sec) - 10 min`).
- **How It Was Fixed:** Complied strictly with R2:
  ```python
  elapsed_seconds = (punch_in_dt - scheduled_start_dt).total_seconds()
  if elapsed_seconds > 600:  # strictly > 10 minutes
      late_minutes = int(elapsed_seconds // 60)
  else:
      late_minutes = 0
  ```

---

### Defect 6: Overtime Threshold & Overnight Shift End Discrepancy
- **Location:** `overtime_minutes` calculation
- **What Was Wrong:**
  1. Starter code counted 15 minutes of overtime when rule R3 requires a minimum 30-minute threshold.
  2. For overnight shifts, scheduled shift end was compared against today's start date rather than `date + 1 day`, causing thousands of negative or huge bogus overtime minutes.
- **How to Reproduce:** Punch out 20 minutes after shift end. Starter code returned `20` overtime minutes instead of `0`.
- **How It Was Fixed:** For overnight shifts, scheduled end datetime is set to `(shift_date + timedelta(days=1))` at `shift_end`. Overtime is only awarded if `overtime_seconds >= 1800` (30 minutes), in whole minutes `int(overtime_seconds // 60)`. Otherwise `0`.

---

### Defect 7: Banker's Rounding (Round-Half-to-Even) in Work Hours
- **Location:** `work_hours` rounding
- **What Was Wrong:** Python's built-in `round(val, 2)` implements IEEE-754 Banker's Rounding (round half to even). E.g., `round(4.455, 2)` rounds down to `4.45` instead of `4.46`. This violates payroll compliance.
- **How to Reproduce:** A duration yielding `4.495` hours with `round()` becomes `4.49` (marking employee as half_day), whereas contractual half-up rounding yields `4.50` (full day).
- **How It Was Fixed:** Used Python `decimal` module with `ROUND_HALF_UP`:
  ```python
  from decimal import Decimal, ROUND_HALF_UP
  hours_dec = Decimal(str(total_seconds)) / Decimal("3600")
  work_hours = float(hours_dec.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))
  ```

---

### Defect 8: Duplicate Employee Creation Race Condition
- **Location:** `POST /employees`
- **What Was Wrong:** Starter code performed an application-level `find_one({"emp_code": code})` check followed by `insert_one()`. Concurrent requests with the same code both passed the check and created duplicates.
- **How to Reproduce:** Fire 10 parallel POST requests with the same `emp_code`. Without a unique index, multiple documents were inserted.
- **How It Was Fixed:** Created a database-enforced unique index on `employees.emp_code`. Wrapped `insert_one` in `try/except DuplicateKeyError` returning HTTP 409 Conflict.

---

### Defect 9: Concurrent Duplicate Punch-In Race Condition
- **Location:** `POST /attendance/punch-in`
- **What Was Wrong:** Looked up existing record via `find_one({"emp_code": code, "date": date})` before inserting. Two rapid requests caused two attendance records for the same employee on the same date.
- **How to Reproduce:** Run two concurrent punch-in calls with `asyncio.gather()`.
- **How It Was Fixed:** Created compound unique index `{ "emp_code": 1, "date": 1 }`. `insert_one` raises `DuplicateKeyError` on race, mapped to HTTP 409 Conflict.

---

### Defect 10: Concurrent Punch-Out Lost Updates & Double Punch-Out
- **Location:** `POST /attendance/punch-out`
- **What Was Wrong:** Read attendance record into memory, calculated values, and then ran `update_one({"_id": doc["_id"]}, ...)`. A second concurrent punch-out could overwrite the record or re-calculate metrics with a different timestamp.
- **How to Reproduce:** Send two simultaneous punch-out requests for an active punch-in. Both returned HTTP 200 with conflicting punch-out times.
- **How It Was Fixed:** Atomic `find_one_and_update` with filter `{"emp_code": emp_code, "date": shift_date, "punch_out": None}`. Only the first request matches; the second finds no record and returns HTTP 409 Conflict.

---

### Defect 11: In-Memory Pagination & Total Count Discrepancy
- **Location:** `GET /attendance` and `GET /employees`
- **What Was Wrong:** Starter code fetched all matching documents via `list(cursor)` into Python memory, sliced using `items[skip:skip+limit]`, and computed `len(items)`. Under 100k records, this exhausted RAM and caused high latency.
- **How to Reproduce:** Seed 100,000 attendance records. Querying page 1 fetched all 100,000 records from MongoDB over the network.
- **How It Was Fixed:** Applied database-side pagination using `cursor.skip(skip).limit(limit)` and `collection.count_documents(filter)`.

---

### Defect 12: In-Memory Sorting & Missing Index Scans
- **Location:** `GET /attendance`
- **What Was Wrong:** Missing compound index on `(date, status)` or `(emp_code, date)` forced MongoDB into an in-memory sort stage (`SORT` without index), crashing if sort exceeded 33MB RAM.
- **How to Reproduce:** Query `/attendance?status=PRESENT` sorted by date descending on 100,000 documents without indexes.
- **How It Was Fixed:** Added index `{ "date": -1, "status": 1 }` and sorted at the database cursor level `.sort("date", -1)`.

---

### Defect 13: Loose Validation Accepting Negative or Corrupt Inputs
- **Location:** Request payload parsing
- **What Was Wrong:** Allowed identical `shift_start` and `shift_end` (e.g. `09:00` to `09:00`), invalid time strings, negative page numbers, or `page_size > 1000`.
- **How to Reproduce:** POST `/employees` with `shift_start: "09:00", shift_end: "09:00"`. Starter accepted it, leading to zero-length shifts and division by zero.
- **How It Was Fixed:** Added Pydantic field validators and model validators asserting `shift_start != shift_end`, regex validation for `HH:MM`, and query constraints `Query(ge=1, le=100)`.

---

### Defect 14: Leaking MongoDB Internal `_id` and BSON Types
- **Location:** Response serialization
- **What Was Wrong:** Returned `_id` as an object or string, exposing database implementation details and violating the strict OpenAPI specification.
- **How to Reproduce:** Call `GET /employees`. The response contained `{"_id": "664c123...", ...}`.
- **How It Was Fixed:** Excluded `_id` using MongoDB projection `{"_id": 0}` and explicit Pydantic response models.

---

### Defect 15: History Audit Trail Serialization Errors
- **Location:** `history` field in `/attendance/{emp_code}/{date}`
- **What Was Wrong:** Audit history stored timestamps as ISO strings or Python datetimes that failed JSON serialization, or returned BSON dates instead of integer epoch milliseconds.
- **How to Reproduce:** Perform a PATCH regularization and inspect `history[0].at`.
- **How It Was Fixed:** Standardized all timestamps in API responses as integer epoch milliseconds truncated to whole seconds.

---

### Defect 16: Lost Updates and Race Conditions in Regularization
- **Location:** `PATCH /attendance/{emp_code}/{date}`
- **What Was Wrong:** Read record, modified array in Python, and replaced the entire document or history array, causing concurrent edits to clobber each other's audit trails.
- **How to Reproduce:** Two managers regularizing different fields simultaneously. One manager's audit log entry vanished.
- **How It Was Fixed:** Atomic `$push` to `history` combined with field updates in a single atomic `find_one_and_update` operation.

---

### Defect 17: Averaging Averages in Department Summary
- **Location:** `GET /analytics/departments/summary`
- **What Was Wrong:** Averaged employee-level attendance rates to compute department average. If Employee A worked 2 days (100%) and Employee B worked 20 days (50%), naive average is `(100 + 50)/2 = 75%`, whereas true weighted attendance rate is `(2 + 10) / (2 + 20) = 54.55%`.
- **How to Reproduce:** Department with unequal employee schedules.
- **How It Was Fixed:** Calculated sums over the raw records in a MongoDB `$group` aggregation pipeline: `(sum(present_days) / sum(expected_days)) * 100`.

---

### Defect 18: Omitting Employees With Zero Attendance Logs
- **Location:** `GET /analytics/employees/{emp_code}/monthly` and `GET /analytics/departments/summary`
- **What Was Wrong:** Executed an inner join (`$lookup` followed by `$unwind`) that silently dropped newly hired or absent employees with zero logs for that month.
- **How to Reproduce:** Query department summary for a department where an employee was on leave for the entire month. Headcount showed 0 or dropped the employee.
- **How It Was Fixed:** Used `$lookup` preserving empty arrays (`$unwind: { preserveNullAndEmptyArrays: true }`), ensuring correct department headcount and individual employee monthly reporting even with zero attendance records.
