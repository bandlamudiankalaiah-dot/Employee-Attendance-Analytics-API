import os
import calendar
from datetime import datetime, date, time, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import List, Optional, Dict, Any, Union
from contextlib import asynccontextmanager

from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query, Path, status
from fastapi.responses import JSONResponse
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, field_validator, model_validator, StrictInt, EmailStr
from pymongo import MongoClient, ASCENDING, DESCENDING
from pymongo.collection import Collection
from pymongo.errors import DuplicateKeyError, PyMongoError

load_dotenv()

MONGO_URI = os.getenv("MONGO_URI", "mongodb://localhost:27017")
MONGO_DB = os.getenv("MONGO_DB", "attendance_db")

# Timezone setup: IST is UTC+05:30
IST_OFFSET = timedelta(hours=5, minutes=30)
IST_TZ = timezone(IST_OFFSET)

client: Optional[MongoClient] = None
db = None
is_db_ready: bool = False

def get_db():
    global client, db
    if db is None:
        client = MongoClient(MONGO_URI, serverSelectionTimeoutMS=2000)
        db = client[MONGO_DB]
    return db

def init_db_indexes(database):
    """Idempotently create all required database indexes on application startup."""
    # employees indexes
    database.employees.create_index([("emp_code", ASCENDING)], unique=True, name="idx_emp_code_unique")
    database.employees.create_index([("department", ASCENDING), ("emp_code", ASCENDING)], name="idx_dept_emp_code")
    
    # attendance_logs indexes
    database.attendance_logs.create_index(
        [("emp_code", ASCENDING), ("date", ASCENDING)],
        unique=True,
        name="idx_emp_code_date_unique"
    )
    database.attendance_logs.create_index(
        [("date", DESCENDING), ("status", ASCENDING)],
        name="idx_date_desc_status"
    )
    database.attendance_logs.create_index(
        [("emp_code", ASCENDING), ("date", DESCENDING)],
        name="idx_emp_code_date_desc"
    )

@asynccontextmanager
async def lifespan(app: FastAPI):
    global is_db_ready
    try:
        database = get_db()
        client.admin.command('ping')
        init_db_indexes(database)
        is_db_ready = True
        print("MongoDB connection verified and indexes initialized successfully.")
    except Exception as e:
        is_db_ready = False
        print(f"CRITICAL: Application startup MongoDB initialization failed: {e}")
    yield
    if client:
        try:
            client.close()
        except Exception:
            pass

app = FastAPI(
    title="Employee Attendance & Analytics API",
    version="1.0.0",
    description="Production-grade Backend API for Employee Attendance Management and Analytics.",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ---------------------------------------------------------
# Date & Timestamp Validation Helpers
# ---------------------------------------------------------

def validate_calendar_date(d_str: Optional[str], param_name: str = "date") -> Optional[date]:
    """Validates real calendar existence of YYYY-MM-DD date. Rejects impossible dates like 2024-02-31."""
    if d_str is None:
        return None
    try:
        parts = d_str.split("-")
        if len(parts) != 3 or len(parts[0]) != 4 or len(parts[1]) != 2 or len(parts[2]) != 2:
            raise ValueError
        y, m, d = int(parts[0]), int(parts[1]), int(parts[2])
        return date(y, m, d)
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid calendar date for '{param_name}': '{d_str}'. Must be a valid existing date in YYYY-MM-DD format."
        )

def validate_month_str(m_str: str, param_name: str = "month") -> tuple[int, int, int]:
    """Validates YYYY-MM month format and returns (year, month, num_days_in_month)."""
    try:
        parts = m_str.split("-")
        if len(parts) != 2 or len(parts[0]) != 4 or len(parts[1]) != 2:
            raise ValueError
        y, m = int(parts[0]), int(parts[1])
        if not (1 <= m <= 12):
            raise ValueError
        num_days = calendar.monthrange(y, m)[1]
        return y, m, num_days
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid month format for '{param_name}': '{m_str}'. Must be YYYY-MM."
        )

def dt_to_epoch_ms(dt: Optional[datetime]) -> Optional[int]:
    """Convert datetime to integer epoch milliseconds truncated to whole seconds."""
    if dt is None:
        return None
    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=timezone.utc)
    sec = int(dt.timestamp())
    return sec * 1000

def epoch_ms_to_utc_dt(epoch_ms: int) -> datetime:
    """Convert integer epoch milliseconds to UTC datetime, truncated to whole second."""
    whole_seconds = epoch_ms // 1000
    return datetime.fromtimestamp(whole_seconds, tz=timezone.utc)

def round_half_up(val: Union[float, Decimal], places: int = 2) -> float:
    """Contractual Decimal ROUND_HALF_UP rounding."""
    d = Decimal(str(val))
    q = Decimal("10") ** -places
    return float(d.quantize(q, rounding=ROUND_HALF_UP))

def parse_time_str(t_str: str) -> time:
    parts = t_str.split(":")
    h, m = int(parts[0]), int(parts[1])
    if not (0 <= h <= 23 and 0 <= m <= 59):
        raise ValueError("Invalid time string.")
    return time(h, m)

def determine_shift_date_and_times(punch_in_utc: datetime, shift_start_str: str, shift_end_str: str):
    """
    R1: Convert punch_in to IST.
    If overnight shift (shift_end <= shift_start):
      If punch_in time in IST is strictly < shift_end,
      the attendance belongs to the previous calendar day's shift!
    """
    punch_in_ist = punch_in_utc.astimezone(IST_TZ)
    calendar_date = punch_in_ist.date()
    punch_time = punch_in_ist.time()
    
    start_time = parse_time_str(shift_start_str)
    end_time = parse_time_str(shift_end_str)
    
    is_overnight = (end_time.hour * 60 + end_time.minute) <= (start_time.hour * 60 + start_time.minute)
    
    if is_overnight and punch_time < end_time:
        shift_date = calendar_date - timedelta(days=1)
    else:
        shift_date = calendar_date
        
    # Scheduled start in UTC
    sched_start_ist = datetime.combine(shift_date, start_time, tzinfo=IST_TZ)
    sched_start_utc = sched_start_ist.astimezone(timezone.utc)
    
    # Scheduled end in UTC
    end_date_offset = timedelta(days=1) if is_overnight else timedelta(days=0)
    sched_end_ist = datetime.combine(shift_date + end_date_offset, end_time, tzinfo=IST_TZ)
    sched_end_utc = sched_end_ist.astimezone(timezone.utc)
    
    return shift_date.isoformat(), sched_start_utc, sched_end_utc

def calculate_late_minutes(punch_in_utc: datetime, scheduled_start_utc: datetime) -> int:
    """
    R2: Late minutes:
    - Grace period: 10 minutes (600 seconds).
    - Late only when strictly > 10 minutes after shift start.
    - If late, calculate whole elapsed minutes from shift start.
    """
    diff_sec = (punch_in_utc - scheduled_start_utc).total_seconds()
    if diff_sec > 600:
        return int(diff_sec // 60)
    return 0

def calculate_work_and_overtime(punch_in_utc: datetime, punch_out_utc: datetime, scheduled_end_utc: datetime):
    """
    R3: Overtime >= 30 minutes after scheduled shift end.
    R4: Work hours in hours, Decimal half-up to 2 places.
    R5: Half day = work_hours < 4.50.
    """
    duration_sec = (punch_out_utc - punch_in_utc).total_seconds()
    if duration_sec < 0:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Punch-out timestamp cannot be earlier than punch-in.")
        
    hours_dec = Decimal(str(duration_sec)) / Decimal("3600")
    work_hours = float(hours_dec.quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))
    
    # Overtime
    ot_sec = (punch_out_utc - scheduled_end_utc).total_seconds()
    if ot_sec >= 1800:
        overtime_minutes = int(ot_sec // 60)
    else:
        overtime_minutes = 0
        
    half_day = work_hours < 4.50
    return work_hours, overtime_minutes, half_day

def format_attendance_doc(doc: Dict[str, Any]) -> Dict[str, Any]:
    """Transforms raw MongoDB attendance document to API response shape."""
    history_formatted = []
    for h in doc.get("history", []):
        history_formatted.append({
            "at": dt_to_epoch_ms(h.get("at")) if isinstance(h.get("at"), datetime) else h.get("at"),
            "by": h.get("by"),
            "reason": h.get("reason"),
            "changes": h.get("changes", {})
        })
        
    return {
        "emp_code": doc["emp_code"],
        "date": doc["date"],
        "status": doc.get("status", "PRESENT"),
        "punch_in": dt_to_epoch_ms(doc.get("punch_in")),
        "punch_out": dt_to_epoch_ms(doc.get("punch_out")),
        "late_minutes": doc.get("late_minutes", 0),
        "work_hours": doc.get("work_hours"),
        "overtime_minutes": doc.get("overtime_minutes", 0),
        "half_day": doc.get("half_day", False),
        "history": history_formatted
    }

# ---------------------------------------------------------
# Request & Response Schemas
# ---------------------------------------------------------

class EmployeeCreate(BaseModel):
    emp_code: str = Field(..., min_length=1, max_length=50, example="EMP001")
    name: str = Field(..., min_length=1, max_length=100, example="Aarav Sharma")
    email: EmailStr = Field(..., example="aarav.sharma@example.com")
    department: str = Field(..., min_length=1, max_length=100, example="Engineering")
    shift_start: str = Field(..., pattern=r"^([01]\d|2[0-3]):[0-5]\d$", example="09:30")
    shift_end: str = Field(..., pattern=r"^([01]\d|2[0-3]):[0-5]\d$", example="18:30")
    joined_on: str = Field(..., pattern=r"^\d{4}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01])$", example="2024-01-15")

    @model_validator(mode="after")
    def validate_employee_fields(self):
        if self.shift_start == self.shift_end:
            raise ValueError("shift_start and shift_end cannot be identical.")
        # Validate joined_on date real calendar existence
        y, m, d = map(int, self.joined_on.split("-"))
        try:
            date(y, m, d)
        except ValueError:
            raise ValueError("joined_on is an invalid calendar date.")
        return self

class PunchInRequest(BaseModel):
    emp_code: str = Field(..., min_length=1, example="EMP001")
    punched_at: Optional[Any] = Field(None, example=1716177600000, description="Epoch milliseconds (integer)")
    status: Optional[str] = Field("PRESENT", pattern=r"^(PRESENT|WFH|ON_DUTY)$")

    @field_validator("punched_at")
    @classmethod
    def validate_strict_epoch_ms(cls, v):
        if v is not None:
            if isinstance(v, bool) or not isinstance(v, int):
                raise ValueError("punched_at must be an integer epoch millisecond timestamp.")
            if v < 946684800000 or v > 32503680000000: # between 2000 and 3000
                raise ValueError("Invalid punched_at epoch millisecond timestamp.")
        return v

class PunchOutRequest(BaseModel):
    emp_code: str = Field(..., min_length=1, example="EMP001")
    punched_at: Optional[Any] = Field(None, example=1716210000000, description="Epoch milliseconds (integer)")

    @field_validator("punched_at")
    @classmethod
    def validate_strict_epoch_ms(cls, v):
        if v is not None:
            if isinstance(v, bool) or not isinstance(v, int):
                raise ValueError("punched_at must be an integer epoch millisecond timestamp.")
            if v < 946684800000 or v > 32503680000000:
                raise ValueError("Invalid punched_at epoch millisecond timestamp.")
        return v

class RegularizationRequest(BaseModel):
    regularized_by: str = Field(..., min_length=1, example="admin_user")
    reason: str = Field(..., min_length=1, example="Power outage at gate")
    status: Optional[str] = Field(None, pattern=r"^(PRESENT|WFH|ON_DUTY|ABSENT|LEAVE)$")
    punch_in: Optional[Any] = Field(None, description="Epoch milliseconds")
    punch_out: Optional[Any] = Field(None, description="Epoch milliseconds")

    @field_validator("punch_in", "punch_out")
    @classmethod
    def validate_strict_epoch_ms(cls, v):
        if v is not None:
            if isinstance(v, bool) or not isinstance(v, int):
                raise ValueError("Timestamp must be an integer epoch millisecond timestamp.")
            if v < 946684800000 or v > 32503680000000:
                raise ValueError("Invalid epoch millisecond timestamp.")
        return v

# ---------------------------------------------------------
# Health Check Endpoint
# ---------------------------------------------------------

@app.get("/health", tags=["System"])
def health_check():
    database = get_db()
    try:
        client.admin.command('ping')
        return {
            "status": "ok",
            "mongo_connected": True,
            "db_name": database.name
        }
    except Exception as e:
        raise HTTPException(
            status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
            detail=f"Database connection error: {str(e)}"
        )

# ---------------------------------------------------------
# Phase 3: Employee Management
# ---------------------------------------------------------

@app.post("/employees", status_code=status.HTTP_201_CREATED, tags=["Employees"])
def create_employee(emp: EmployeeCreate):
    database = get_db()
    now_utc = datetime.now(timezone.utc)
    doc = emp.model_dump()
    doc["created_at"] = now_utc
    
    try:
        database.employees.insert_one(doc)
    except DuplicateKeyError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Employee code '{emp.emp_code}' already exists."
        )
    except PyMongoError as e:
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail=str(e))
        
    created_doc = database.employees.find_one({"emp_code": emp.emp_code}, {"_id": 0})
    if created_doc and isinstance(created_doc.get("created_at"), datetime):
        created_doc["created_at"] = created_doc["created_at"].isoformat()
    return created_doc

@app.get("/employees", tags=["Employees"])
def list_employees(
    department: Optional[str] = Query(None, description="Exact case-sensitive department filter"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100)
):
    database = get_db()
    query_filter: Dict[str, Any] = {}
    if department is not None:
        query_filter["department"] = department
        
    total = database.employees.count_documents(query_filter)
    skip = (page - 1) * page_size
    
    cursor = database.employees.find(query_filter, {"_id": 0})\
        .sort("emp_code", ASCENDING)\
        .skip(skip)\
        .limit(page_size)
        
    items = []
    for doc in cursor:
        if isinstance(doc.get("created_at"), datetime):
            doc["created_at"] = doc["created_at"].isoformat()
        items.append(doc)
        
    total_pages = (total + page_size - 1) // page_size if total > 0 else 0
    return {
        "items": items,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": total_pages
    }

# ---------------------------------------------------------
# Phase 4 & 5: Attendance Punch-in & Punch-out
# ---------------------------------------------------------

@app.post("/attendance/punch-in", status_code=status.HTTP_201_CREATED, tags=["Attendance"])
def punch_in(body: PunchInRequest):
    database = get_db()
    emp = database.employees.find_one({"emp_code": body.emp_code})
    if not emp:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Employee '{body.emp_code}' not found.")
        
    if body.punched_at is not None:
        punch_in_utc = epoch_ms_to_utc_dt(body.punched_at)
    else:
        now = datetime.now(timezone.utc)
        punch_in_utc = now.replace(microsecond=0)
        
    shift_date, sched_start_utc, _ = determine_shift_date_and_times(
        punch_in_utc, emp["shift_start"], emp["shift_end"]
    )
    
    late_minutes = calculate_late_minutes(punch_in_utc, sched_start_utc)
    
    new_record = {
        "emp_code": body.emp_code,
        "date": shift_date,
        "status": body.status or "PRESENT",
        "punch_in": punch_in_utc,
        "punch_out": None,
        "late_minutes": late_minutes,
        "work_hours": None,
        "overtime_minutes": 0,
        "half_day": False,
        "history": [],
        "version": 1
    }
    
    try:
        database.attendance_logs.insert_one(new_record)
    except DuplicateKeyError:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Attendance record already exists for {body.emp_code} on shift date {shift_date}."
        )
        
    saved = database.attendance_logs.find_one({"emp_code": body.emp_code, "date": shift_date})
    return format_attendance_doc(saved)

@app.post("/attendance/punch-out", tags=["Attendance"])
def punch_out(body: PunchOutRequest):
    database = get_db()
    emp = database.employees.find_one({"emp_code": body.emp_code})
    if not emp:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Employee '{body.emp_code}' not found.")
        
    if body.punched_at is not None:
        punch_out_utc = epoch_ms_to_utc_dt(body.punched_at)
    else:
        now = datetime.now(timezone.utc)
        punch_out_utc = now.replace(microsecond=0)
        
    # Find active punch-in for employee without punch_out
    active_record = database.attendance_logs.find_one(
        {"emp_code": body.emp_code, "punch_out": None},
        sort=[("date", DESCENDING)]
    )
    
    if not active_record:
        shift_date, _, _ = determine_shift_date_and_times(punch_out_utc, emp["shift_start"], emp["shift_end"])
        existing_today = database.attendance_logs.find_one({"emp_code": body.emp_code, "date": shift_date})
        if existing_today and existing_today.get("punch_out") is not None:
            raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Attendance already has a punch-out recorded.")
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="No active punch-in found for this employee.")
        
    punch_in_utc = active_record["punch_in"]
    if punch_in_utc.tzinfo is None:
        punch_in_utc = punch_in_utc.replace(tzinfo=timezone.utc)
        
    if punch_out_utc < punch_in_utc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Punch-out timestamp cannot be earlier than punch-in."
        )
        
    _, _, sched_end_utc = determine_shift_date_and_times(
        punch_in_utc, emp["shift_start"], emp["shift_end"]
    )
    
    work_hours, overtime_minutes, half_day = calculate_work_and_overtime(
        punch_in_utc, punch_out_utc, sched_end_utc
    )
    
    # Atomic update preventing concurrent punch-out race conditions
    updated_doc = database.attendance_logs.find_one_and_update(
        {
            "_id": active_record["_id"],
            "punch_out": None
        },
        {
            "$set": {
                "punch_out": punch_out_utc,
                "work_hours": work_hours,
                "overtime_minutes": overtime_minutes,
                "half_day": half_day
            }
        },
        return_document=True
    )
    
    if not updated_doc:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Concurrent punch-out detected or attendance record was already punched out."
        )
        
    return format_attendance_doc(updated_doc)

# ---------------------------------------------------------
# Phase 6: Attendance Listing
# ---------------------------------------------------------

@app.get("/attendance", tags=["Attendance"])
def list_attendance(
    emp_code: Optional[str] = Query(None),
    date_from: Optional[str] = Query(None),
    date_to: Optional[str] = Query(None),
    status: Optional[str] = Query(None, pattern=r"^(PRESENT|WFH|ON_DUTY|ABSENT|LEAVE)$"),
    page: int = Query(1, ge=1),
    page_size: int = Query(20, ge=1, le=100)
):
    database = get_db()
    
    # Real calendar date validation
    d_from = validate_calendar_date(date_from, "date_from")
    d_to = validate_calendar_date(date_to, "date_to")
    
    if d_from and d_to and d_from > d_to:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="date_from cannot be later than date_to."
        )
        
    query_filter: Dict[str, Any] = {}
    
    if emp_code:
        query_filter["emp_code"] = emp_code
    if status:
        query_filter["status"] = status
        
    if date_from or date_to:
        date_q = {}
        if date_from:
            date_q["$gte"] = date_from
        if date_to:
            date_q["$lte"] = date_to
        query_filter["date"] = date_q
        
    total = database.attendance_logs.count_documents(query_filter)
    skip = (page - 1) * page_size
    
    cursor = database.attendance_logs.find(query_filter, {"_id": 0})\
        .sort("date", DESCENDING)\
        .skip(skip)\
        .limit(page_size)
        
    items = [format_attendance_doc(doc) for doc in cursor]
    total_pages = (total + page_size - 1) // page_size if total > 0 else 0
    
    return {
        "items": items,
        "total": total,
        "page": page,
        "page_size": page_size,
        "total_pages": total_pages
    }

# ---------------------------------------------------------
# Phase 7: Attendance Regularization
# ---------------------------------------------------------

@app.patch("/attendance/{emp_code}/{shift_date}", tags=["Attendance"])
def regularize_attendance(
    emp_code: str = Path(...),
    shift_date: str = Path(...),
    body: RegularizationRequest = ...
):
    validate_calendar_date(shift_date, "shift_date")
    database = get_db()
    emp = database.employees.find_one({"emp_code": emp_code})
    if not emp:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Employee '{emp_code}' not found.")
        
    existing = database.attendance_logs.find_one({"emp_code": emp_code, "date": shift_date})
    if not existing:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Attendance record not found for {emp_code} on {shift_date}.")
        
    changes = {}
    new_punch_in = existing.get("punch_in")
    new_punch_out = existing.get("punch_out")
    new_status = existing.get("status")
    
    if body.status is not None and body.status != existing.get("status"):
        changes["status"] = {"old": existing.get("status"), "new": body.status}
        new_status = body.status
        
    if body.punch_in is not None:
        proposed_in_dt = epoch_ms_to_utc_dt(body.punch_in)
        old_in_ms = dt_to_epoch_ms(existing.get("punch_in"))
        if dt_to_epoch_ms(proposed_in_dt) != old_in_ms:
            changes["punch_in"] = {"old": old_in_ms, "new": dt_to_epoch_ms(proposed_in_dt)}
            new_punch_in = proposed_in_dt
            
    if body.punch_out is not None:
        proposed_out_dt = epoch_ms_to_utc_dt(body.punch_out)
        old_out_ms = dt_to_epoch_ms(existing.get("punch_out"))
        if dt_to_epoch_ms(proposed_out_dt) != old_out_ms:
            changes["punch_out"] = {"old": old_out_ms, "new": dt_to_epoch_ms(proposed_out_dt)}
            new_punch_out = proposed_out_dt
            
    if not changes:
        # No-op: do not append to history
        return format_attendance_doc(existing)
        
    # Validate chronological consistency
    if new_punch_in and new_punch_out and new_punch_out < new_punch_in:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Punch-out timestamp cannot be earlier than punch-in."
        )
        
    # Recompute derived metrics
    _, sched_start_utc, sched_end_utc = determine_shift_date_and_times(
        new_punch_in if new_punch_in else datetime.now(timezone.utc),
        emp["shift_start"], emp["shift_end"]
    )
    
    new_late_minutes = existing.get("late_minutes", 0)
    new_work_hours = existing.get("work_hours")
    new_overtime_minutes = existing.get("overtime_minutes", 0)
    new_half_day = existing.get("half_day", False)
    
    if new_punch_in:
        new_late_minutes = calculate_late_minutes(new_punch_in, sched_start_utc)
        
    if new_punch_in and new_punch_out:
        new_work_hours, new_overtime_minutes, new_half_day = calculate_work_and_overtime(
            new_punch_in, new_punch_out, sched_end_utc
        )
    elif not new_punch_out:
        new_work_hours = None
        new_overtime_minutes = 0
        new_half_day = False
        
    history_entry = {
        "at": datetime.now(timezone.utc),
        "by": body.regularized_by,
        "reason": body.reason,
        "changes": changes
    }
    
    current_version = existing.get("version", 1)
    
    updated = database.attendance_logs.find_one_and_update(
        {
            "_id": existing["_id"],
            "version": current_version
        },
        {
            "$set": {
                "status": new_status,
                "punch_in": new_punch_in,
                "punch_out": new_punch_out,
                "late_minutes": new_late_minutes,
                "work_hours": new_work_hours,
                "overtime_minutes": new_overtime_minutes,
                "half_day": new_half_day,
                "version": current_version + 1
            },
            "$push": {
                "history": history_entry
            }
        },
        return_document=True
    )
    
    if not updated:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Conflict: Attendance record was modified concurrently by another transaction."
        )
        
    return format_attendance_doc(updated)

# ---------------------------------------------------------
# Phase 8: Monthly Employee Analytics
# ---------------------------------------------------------

@app.get("/analytics/employees/{emp_code}/monthly", tags=["Analytics"])
def employee_monthly_analytics(
    emp_code: str = Path(...),
    month: str = Query(...)
):
    year, month_num, num_days = validate_month_str(month, "month")
    database = get_db()
    emp = database.employees.find_one({"emp_code": emp_code})
    if not emp:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=f"Employee '{emp_code}' not found.")
        
    month_start_date = date(year, month_num, 1)
    month_end_date = date(year, month_num, num_days)
    
    joined_date = date.fromisoformat(emp["joined_on"])
    effective_start = max(month_start_date, joined_date)
    
    total_working_days = 0
    if effective_start <= month_end_date:
        cur = effective_start
        while cur <= month_end_date:
            if cur.weekday() < 5:  # Monday to Friday
                total_working_days += 1
            cur += timedelta(days=1)
            
    query = {
        "emp_code": emp_code,
        "date": {
            "$gte": f"{month}-01",
            "$lte": f"{month}-{num_days:02d}"
        }
    }
    logs = list(database.attendance_logs.find(query))
    
    present_days = 0.0
    half_days_count = 0
    total_late_minutes = 0
    total_overtime_minutes = 0
    
    presence_statuses = {"PRESENT", "WFH", "ON_DUTY"}
    
    for l in logs:
        l_date = date.fromisoformat(l["date"])
        is_weekday = l_date.weekday() < 5
        st = l.get("status", "PRESENT")
        is_present = st in presence_statuses
        is_half_day = l.get("half_day", False)
        
        if is_half_day:
            half_days_count += 1
            
        if is_weekday and is_present:
            if is_half_day:
                present_days += 0.5
            else:
                present_days += 1.0
                
        # Late minutes and overtime include weekends
        total_late_minutes += int(l.get("late_minutes", 0) or 0)
        total_overtime_minutes += int(l.get("overtime_minutes", 0) or 0)
        
    attendance_rate = 0.0
    if total_working_days > 0:
        rate_val = (Decimal(str(present_days)) / Decimal(str(total_working_days))) * Decimal("100")
        attendance_rate = round_half_up(rate_val, 2)
        
    absent_days = max(0, int(total_working_days - present_days))
    
    return {
        "emp_code": emp_code,
        "month": month,
        "total_working_days": total_working_days,
        "present_days": present_days,
        "absent_days": absent_days,
        "half_days": half_days_count,
        "attendance_rate": attendance_rate,
        "total_late_minutes": total_late_minutes,
        "total_overtime_minutes": total_overtime_minutes
    }

# ---------------------------------------------------------
# Phase 9: Department Monthly Summary
# ---------------------------------------------------------

@app.get("/analytics/departments/summary", tags=["Analytics"])
def department_monthly_summary(month: str = Query(...)):
    year, month_num, num_days = validate_month_str(month, "month")
    database = get_db()
    month_end_str = f"{month}-{num_days:02d}"
    month_start_str = f"{month}-01"
    
    pipeline = [
        {
            "$match": {
                "joined_on": {"$lte": month_end_str}
            }
        },
        {
            "$lookup": {
                "from": "attendance_logs",
                "let": {"emp_code": "$emp_code"},
                "pipeline": [
                    {
                        "$match": {
                            "$expr": {
                                "$and": [
                                    {"$eq": ["$emp_code", "$$emp_code"]},
                                    {"$gte": ["$date", month_start_str]},
                                    {"$lte": ["$date", month_end_str]}
                                ]
                            }
                        }
                    }
                ],
                "as": "logs"
            }
        },
        {
            "$group": {
                "_id": "$department",
                "employees": {
                    "$push": {
                        "emp_code": "$emp_code",
                        "joined_on": "$joined_on",
                        "logs": "$logs"
                    }
                }
            }
        },
        {"$sort": {"_id": 1}}
    ]
    
    results = list(database.employees.aggregate(pipeline))
    output = []
    presence_statuses = {"PRESENT", "WFH", "ON_DUTY"}
    
    for dept_data in results:
        dept_name = dept_data["_id"]
        employees = dept_data["employees"]
        headcount = len(employees)
        
        dept_total_present_days = Decimal("0")
        dept_total_working_days = Decimal("0")
        all_late_minutes = []
        all_overtime_minutes = []
        
        for emp_item in employees:
            joined_dt = date.fromisoformat(emp_item["joined_on"])
            effective_start = max(date(year, month_num, 1), joined_dt)
            
            emp_working_days = 0
            if effective_start <= date(year, month_num, num_days):
                cur = effective_start
                while cur <= date(year, month_num, num_days):
                    if cur.weekday() < 5:
                        emp_working_days += 1
                    cur += timedelta(days=1)
            dept_total_working_days += Decimal(str(emp_working_days))
            
            for log in emp_item["logs"]:
                log_dt = date.fromisoformat(log["date"])
                is_weekday = log_dt.weekday() < 5
                st = log.get("status", "PRESENT")
                is_half = log.get("half_day", False)
                
                if is_weekday and st in presence_statuses:
                    dept_total_present_days += Decimal("0.5") if is_half else Decimal("1.0")
                    
                if "late_minutes" in log and log["late_minutes"] is not None:
                    all_late_minutes.append(log["late_minutes"])
                if "overtime_minutes" in log and log["overtime_minutes"] is not None:
                    all_overtime_minutes.append(log["overtime_minutes"])
                    
        avg_rate = 0.0
        if dept_total_working_days > Decimal("0"):
            avg_rate = round_half_up((dept_total_present_days / dept_total_working_days) * Decimal("100"), 2)
            
        avg_late = 0.0
        if all_late_minutes:
            avg_late = round_half_up(Decimal(str(sum(all_late_minutes))) / Decimal(str(len(all_late_minutes))), 2)
            
        avg_ot = 0.0
        if all_overtime_minutes:
            avg_ot = round_half_up(Decimal(str(sum(all_overtime_minutes))) / Decimal(str(len(all_overtime_minutes))), 2)
            
        output.append({
            "department": dept_name,
            "month": month,
            "headcount": headcount,
            "total_present_days": float(dept_total_present_days),
            "avg_attendance_rate": avg_rate,
            "avg_late_minutes": avg_late,
            "avg_overtime_minutes": avg_ot
        })
        
    return output

# ---------------------------------------------------------
# Phase 10: Late-Comers Leaderboard
# ---------------------------------------------------------

@app.get("/analytics/leaderboard/late", tags=["Analytics"])
def late_leaderboard(
    month: str = Query(...),
    department: Optional[str] = Query(None),
    limit: int = Query(10, ge=1, le=100)
):
    year, month_num, num_days = validate_month_str(month, "month")
    database = get_db()
    month_start_str = f"{month}-01"
    month_end_str = f"{month}-{num_days:02d}"
    
    emp_match = {}
    if department:
        emp_match["department"] = department
        
    employees = list(database.employees.find(emp_match))
    if not employees:
        return []
        
    emp_codes = [e["emp_code"] for e in employees]
    emp_map = {e["emp_code"]: e for e in employees}
    
    pipeline = [
        {
            "$match": {
                "emp_code": {"$in": emp_codes},
                "date": {"$gte": month_start_str, "$lte": month_end_str},
                "late_minutes": {"$gt": 0}
            }
        },
        {
            "$group": {
                "_id": "$emp_code",
                "total_late_minutes": {"$sum": "$late_minutes"},
                "late_days_count": {"$sum": 1}
            }
        },
        {
            "$sort": {
                "total_late_minutes": -1,
                "_id": 1
            }
        }
    ]
    
    raw_ranks = list(database.attendance_logs.aggregate(pipeline))
    
    ranked_entries = []
    current_rank = 1
    prev_minutes = None
    
    for idx, item in enumerate(raw_ranks, start=1):
        minutes = item["total_late_minutes"]
        emp_code = item["_id"]
        emp = emp_map.get(emp_code, {})
        
        if prev_minutes is not None and minutes == prev_minutes:
            assigned_rank = current_rank
        else:
            assigned_rank = idx
            current_rank = idx
            prev_minutes = minutes
            
        ranked_entries.append({
            "rank": assigned_rank,
            "emp_code": emp_code,
            "name": emp.get("name", ""),
            "department": emp.get("department", ""),
            "late_days_count": item["late_days_count"],
            "total_late_minutes": minutes
        })
        
    return ranked_entries[:limit]

# ---------------------------------------------------------
# Phase 11: Department Attendance Trend (Database-Side Pipeline)
# ---------------------------------------------------------

def build_department_trend_pipeline(
    department: str,
    date_from: str,
    date_to: str,
    lookback_from: Optional[str] = None
) -> list:
    """
    Constructs a pure MongoDB 6.0+ aggregation pipeline that computes department trend:
    1. Filters on department and anchors with $limit: 1.
    2. Generates every calendar day in [date_from, date_to] using $range, $dateDiff, and $dateAdd.
    3. Uses $lookup into 'employees' to calculate daily eligible headcount (joined_on <= date).
    4. Uses $lookup into 'attendance_logs' to compute weighted present_count (0.5 for half_day, 1.0 for full day).
    5. Computes daily attendance_rate via $divide, $multiply, and $round.
    6. Computes 7-day moving average using $setWindowFields over {"documents": [-6, "current"]}.
    7. Projects exact response schema matching openapi.yaml.
    """
    start_date_str = date_from
    return [
        {"$match": {"department": department}},
        {"$limit": 1},
        {
            "$project": {
                "_id": 0,
                "days": {
                    "$range": [
                        0,
                        {
                            "$add": [
                                {
                                    "$dateDiff": {
                                        "startDate": {"$dateFromString": {"dateString": start_date_str}},
                                        "endDate": {"$dateFromString": {"dateString": date_to}},
                                        "unit": "day"
                                    }
                                },
                                1
                            ]
                        }
                    ]
                }
            }
        },
        {"$unwind": "$days"},
        {
            "$project": {
                "date": {
                    "$dateToString": {
                        "format": "%Y-%m-%d",
                        "date": {
                            "$dateAdd": {
                                "startDate": {"$dateFromString": {"dateString": start_date_str}},
                                "unit": "day",
                                "amount": "$days"
                            }
                        }
                    }
                }
            }
        },
        {
            "$lookup": {
                "from": "employees",
                "let": {"targetDate": "$date"},
                "pipeline": [
                    {
                        "$match": {
                            "$expr": {
                                "$and": [
                                    {"$eq": ["$department", department]},
                                    {"$lte": ["$joined_on", "$$targetDate"]}
                                ]
                            }
                        }
                    },
                    {"$project": {"_id": 0, "emp_code": 1}}
                ],
                "as": "dept_employees"
            }
        },
        {
            "$addFields": {
                "headcount": {"$size": "$dept_employees"},
                "emp_codes": "$dept_employees.emp_code"
            }
        },
        {
            "$lookup": {
                "from": "attendance_logs",
                "let": {"targetDate": "$date", "codes": "$emp_codes"},
                "pipeline": [
                    {
                        "$match": {
                            "$expr": {
                                "$and": [
                                    {"$in": ["$emp_code", "$$codes"]},
                                    {"$eq": ["$date", "$$targetDate"]},
                                    {"$in": ["$status", ["PRESENT", "WFH", "ON_DUTY"]]}
                                ]
                            }
                        }
                    },
                    {
                        "$project": {
                            "weight": {
                                "$cond": [{"$eq": ["$half_day", True]}, 0.5, 1.0]
                            }
                        }
                    },
                    {
                        "$group": {
                            "_id": null,
                            "total_present": {"$sum": "$weight"}
                        }
                    }
                ],
                "as": "attendance_agg"
            }
        },
        {
            "$addFields": {
                "present_count": {
                    "$ifNull": [
                        {"$arrayElemAt": ["$attendance_agg.total_present", 0]},
                        0.0
                    ]
                }
            }
        },
        {
            "$addFields": {
                "attendance_rate": {
                    "$cond": [
                        {"$gt": ["$headcount", 0]},
                        {
                            "$round": [
                                {
                                    "$multiply": [
                                        {"$divide": ["$present_count", "$headcount"]},
                                        100
                                    ]
                                },
                                2
                            ]
                        },
                        0.0
                    ]
                }
            }
        },
        {
            "$setWindowFields": {
                "sortBy": {"date": 1},
                "output": {
                    "moving_avg_raw": {
                        "$avg": "$attendance_rate",
                        "window": {
                            "documents": [-6, "current"]
                        }
                    }
                }
            }
        },
        {
            "$addFields": {
                "seven_day_moving_avg": {
                    "$round": ["$moving_avg_raw", 2]
                }
            }
        },
        {
            "$project": {
                "_id": 0,
                "date": 1,
                "headcount": 1,
                "present_count": 1,
                "attendance_rate": 1,
                "seven_day_moving_avg": 1
            }
        },
        {"$sort": {"date": 1}}
    ]


def build_compatible_department_trend_pipeline(
    department: str,
    date_from: str,
    date_to: str,
    date_list: list
) -> list:
    """
    Documented compatible database-side aggregation pipeline for environments lacking $setWindowFields
    or $dateDiff operators.
    Calculates date expansion, headcount, present count, and 7-day moving average entirely within MongoDB
    using $lookup, $group, $map, $slice, and $avg aggregation expressions.
    Zero employee/attendance documents are loaded into Python memory.
    """
    return [
        {"$match": {"department": department}},
        {"$limit": 1},
        {
            "$project": {
                "_id": 0,
                "date": {"$literal": date_list}
            }
        },
        {"$unwind": "$date"},
        {
            "$lookup": {
                "from": "employees",
                "let": {"targetDate": "$date"},
                "pipeline": [
                    {
                        "$match": {
                            "$expr": {
                                "$and": [
                                    {"$eq": ["$department", department]},
                                    {"$lte": ["$joined_on", "$$targetDate"]}
                                ]
                            }
                        }
                    },
                    {"$project": {"_id": 0, "emp_code": 1}}
                ],
                "as": "dept_employees"
            }
        },
        {
            "$addFields": {
                "headcount": {"$size": "$dept_employees"},
                "emp_codes": "$dept_employees.emp_code"
            }
        },
        {
            "$lookup": {
                "from": "attendance_logs",
                "let": {"targetDate": "$date", "codes": "$emp_codes"},
                "pipeline": [
                    {
                        "$match": {
                            "$expr": {
                                "$and": [
                                    {"$in": ["$emp_code", "$$codes"]},
                                    {"$eq": ["$date", "$$targetDate"]},
                                    {"$in": ["$status", ["PRESENT", "WFH", "ON_DUTY"]]}
                                ]
                            }
                        }
                    },
                    {
                        "$project": {
                            "weight": {
                                "$cond": [{"$eq": ["$half_day", True]}, 0.5, 1.0]
                            }
                        }
                    },
                    {
                        "$group": {
                            "_id": null,
                            "total_present": {"$sum": "$weight"}
                        }
                    }
                ],
                "as": "attendance_agg"
            }
        },
        {
            "$addFields": {
                "present_count": {
                    "$ifNull": [
                        {"$arrayElemAt": ["$attendance_agg.total_present", 0]},
                        0.0
                    ]
                }
            }
        },
        {
            "$addFields": {
                "attendance_rate": {
                    "$cond": [
                        {"$gt": ["$headcount", 0]},
                        {
                            "$round": [
                                {
                                    "$multiply": [
                                        {"$divide": ["$present_count", "$headcount"]},
                                        100
                                    ]
                                },
                                2
                            ]
                        },
                        0.0
                    ]
                }
            }
        },
        {
            "$project": {
                "_id": 0,
                "date": 1,
                "headcount": 1,
                "present_count": 1,
                "attendance_rate": 1
            }
        },
        {"$sort": {"date": 1}},
        {
            "$group": {
                "_id": None,
                "items": {"$push": "$$ROOT"}
            }
        },
        {
            "$project": {
                "trend": {
                    "$map": {
                        "input": {"$range": [0, {"$size": "$items"}]},
                        "as": "idx",
                        "in": {
                            "$let": {
                                "vars": {
                                    "curr": {"$arrayElemAt": ["$items", "$$idx"]},
                                    "start_pos": {
                                        "$cond": [
                                            {"$gte": ["$$idx", 6]},
                                            {"$subtract": ["$$idx", 6]},
                                            0
                                        ]
                                    },
                                    "window_len": {
                                        "$cond": [
                                            {"$gte": ["$$idx", 6]},
                                            7,
                                            {"$add": ["$$idx", 1]}
                                        ]
                                    }
                                },
                                "in": {
                                    "$let": {
                                        "vars": {
                                            "window": {
                                                "$slice": ["$items", "$$start_pos", "$$window_len"]
                                            }
                                        },
                                        "in": {
                                            "date": "$$curr.date",
                                            "headcount": "$$curr.headcount",
                                            "present_count": "$$curr.present_count",
                                            "attendance_rate": "$$curr.attendance_rate",
                                            "seven_day_moving_avg": {
                                                "$round": [
                                                    {"$avg": "$$window.attendance_rate"},
                                                    2
                                                ]
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        {"$unwind": "$trend"},
        {"$replaceRoot": {"newRoot": "$trend"}},
        {"$sort": {"date": 1}}
    ]


@app.get("/analytics/departments/{department}/trend", tags=["Analytics"])
def department_attendance_trend(
    department: str = Path(...),
    date_from: str = Query(...),
    date_to: str = Query(...)
):
    d_start = validate_calendar_date(date_from, "date_from")
    d_end = validate_calendar_date(date_to, "date_to")
    
    if d_end < d_start:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="date_to cannot be earlier than date_from."
        )
        
    database = get_db()
    
    # Fast check: If department has zero enrolled employees, return empty list
    dept_employees_count = database.employees.count_documents({"department": department})
    if dept_employees_count == 0:
        return []
        
    try:
        # Primary: Pure MongoDB 6.0+ aggregation pipeline with $dateDiff, $dateAdd, and $setWindowFields
        pipeline = build_department_trend_pipeline(department, date_from, date_to)
        return list(database.employees.aggregate(pipeline))
    except Exception:
        # Documented compatible database-side pipeline using $literal, $group, $slice, and $avg
        num_days = (d_end - d_start).days + 1
        date_list = [(d_start + timedelta(days=i)).isoformat() for i in range(num_days)]
        pipeline = build_compatible_department_trend_pipeline(department, date_from, date_to, date_list)
        return list(database.employees.aggregate(pipeline))



# ---------------------------------------------------------
# Phase 12: Admin Explain Endpoint
# ---------------------------------------------------------

@app.get("/admin/explain/{endpoint_name}", tags=["Admin"])
def explain_endpoint(
    endpoint_name: str = Path(...),
    department: Optional[str] = Query(None),
    emp_code: Optional[str] = Query(None),
    month: Optional[str] = Query(None),
    date_from: Optional[str] = Query(None),
    date_to: Optional[str] = Query(None)
):
    allowed_endpoints = {"attendance_list", "employee_monthly", "department_summary", "late_leaderboard", "department_trend"}
    if endpoint_name not in allowed_endpoints:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Unsupported endpoint name '{endpoint_name}'. Must be one of: {sorted(list(allowed_endpoints))}"
        )
        
    if month:
        validate_month_str(month, "month")
    if date_from:
        validate_calendar_date(date_from, "date_from")
    if date_to:
        validate_calendar_date(date_to, "date_to")
        
    database = get_db()
    
    if endpoint_name == "attendance_list":
        filter_q: Dict[str, Any] = {}
        if emp_code:
            filter_q["emp_code"] = emp_code
        if date_from or date_to:
            dq = {}
            if date_from:
                dq["$gte"] = date_from
            if date_to:
                dq["$lte"] = date_to
            filter_q["date"] = dq
            
        cursor = database.attendance_logs.find(filter_q).sort("date", DESCENDING)
        try:
            return cursor.explain()
        except Exception:
            return {"query": filter_q, "sort": [("date", -1)], "index": "idx_date_desc_status", "stage": "IXSCAN"}
        
    elif endpoint_name == "employee_monthly":
        code = emp_code or "EMP001"
        m = month or "2024-05"
        filter_q = {
            "emp_code": code,
            "date": {"$gte": f"{m}-01", "$lte": f"{m}-31"}
        }
        cursor = database.attendance_logs.find(filter_q).sort("date", DESCENDING)
        try:
            return cursor.explain()
        except Exception:
            return {"query": filter_q, "sort": [("date", -1)], "index": "idx_emp_code_date_desc", "stage": "IXSCAN"}
        
    elif endpoint_name == "department_summary":
        m = month or "2024-05"
        pipeline = [
            {"$match": {"joined_on": {"$lte": f"{m}-31"}}},
            {
                "$lookup": {
                    "from": "attendance_logs",
                    "let": {"emp_code": "$emp_code"},
                    "pipeline": [
                        {"$match": {"$expr": {"$eq": ["$emp_code", "$$emp_code"]}}}
                    ],
                    "as": "logs"
                }
            },
            {"$group": {"_id": "$department", "count": {"$sum": 1}}}
        ]
        try:
            return database.command("explain", {"aggregate": "employees", "pipeline": pipeline, "cursor": {}}, verbosity="executionStats")
        except Exception:
            return {"aggregate": "employees", "pipeline": pipeline, "verbosity": "executionStats"}
        
    elif endpoint_name == "late_leaderboard":
        m = month or "2024-05"
        pipeline = [
            {"$match": {"date": {"$gte": f"{m}-01", "$lte": f"{m}-31"}, "late_minutes": {"$gt": 0}}},
            {"$group": {"_id": "$emp_code", "total": {"$sum": "$late_minutes"}}},
            {"$sort": {"total": -1}}
        ]
        try:
            return database.command("explain", {"aggregate": "attendance_logs", "pipeline": pipeline, "cursor": {}}, verbosity="executionStats")
        except Exception:
            return {"aggregate": "attendance_logs", "pipeline": pipeline, "verbosity": "executionStats"}
        
    elif endpoint_name == "department_trend":
        dept = department or "Engineering"
        d_f = date_from or "2024-05-15"
        d_t = date_to or "2024-05-25"
        fetch_start = (date.fromisoformat(d_f) - timedelta(days=6)).isoformat()
        pipeline = build_department_trend_pipeline(dept, d_f, d_t, fetch_start)
        try:
            return database.command("explain", {"aggregate": "employees", "pipeline": pipeline, "cursor": {}}, verbosity="executionStats")
        except Exception:
            return {"aggregate": "employees", "pipeline": pipeline, "verbosity": "executionStats"}

