import os
import pytest
from pymongo import MongoClient
from fastapi.testclient import TestClient

# Configure environment before loading app
os.environ["MONGO_URI"] = os.getenv("MONGO_URI", "mongodb://localhost:27017")
os.environ["MONGO_DB"] = os.getenv("MONGO_DB", "test_attendance_db")

import app.main as app_module
from app.main import app

try:
    from mongomock import MongoClient as MockMongoClient
except ImportError:
    MockMongoClient = None

@pytest.fixture(autouse=True)
def setup_test_db(monkeypatch):
    """
    Sets up an isolated test database.
    Attempts to connect to a real MongoDB instance first for true database-side pipeline verification.
    If real MongoDB is unavailable, gracefully falls back to MockMongoClient.
    """
    uri = os.environ["MONGO_URI"]
    db_name = os.environ["MONGO_DB"]
    
    real_client = None
    try:
        real_client = MongoClient(uri, serverSelectionTimeoutMS=600)
        real_client.admin.command('ping')
        test_db = real_client[db_name]
        test_db.employees.delete_many({})
        test_db.attendance_logs.delete_many({})
        monkeypatch.setattr(app_module, "client", real_client)
        monkeypatch.setattr(app_module, "db", test_db)
        app_module.init_db_indexes(test_db)
        yield test_db
        test_db.employees.delete_many({})
        test_db.attendance_logs.delete_many({})
        real_client.close()
        return
    except Exception:
        if real_client:
            try:
                real_client.close()
            except Exception:
                pass

    if MockMongoClient is not None:
        mock_client = MockMongoClient()
        mock_db = mock_client[db_name]
        monkeypatch.setattr(app_module, "client", mock_client)
        monkeypatch.setattr(app_module, "db", mock_db)
        app_module.init_db_indexes(mock_db)
        yield mock_db
        mock_client.close()
    else:
        pytest.skip("Neither live MongoDB nor mongomock is available.")

@pytest.fixture
def client(setup_test_db):
    with TestClient(app) as test_client:
        yield test_client
